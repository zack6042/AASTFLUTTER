import 'package:flutter/material.dart';
import 'package:sql_conn/sql_conn.dart';

List<DataRow> displayrows = [];
List<String> rows = [];
var StID = [];
var Fname = [];
var Lname = [];
var ManID = [];

class showscreen extends StatefulWidget {
 final String res;
   showscreen(this.res);
   void setRows()
   {
     displayrows.clear();
     StID.clear();
     Fname.clear();
     Lname.clear();
     ManID.clear();
     try {
       rows = res.split('}, ');
       rows.forEach((element) {
         element = element.replaceAll(RegExp(r"[{[}\],]"), '');
         List tokens = element.split(' ');
         for (int i = 0; i < tokens.length; i++) {
           tokens[i] = tokens[i].replaceAll(RegExp(r'["]'), '');
         }

         tokens.forEach((token) {
           var key, value;
           token = token.replaceFirst(RegExp(r':'), '%');
           key = token.split('%')[0];
           value = token.split('%')[1];
           if (key == 'studid') {
             StID.add(value.toString());
           }
           else if (key == 'studfname') {
             Fname.add(value);
           }
           else if (key == 'studlname') {
             Lname.add(value);
           }
           else if (key == 'st_manid') {
             ManID.add(value);
           }
         });
       });
       for (int i = 0; i < StID.length; i++) {
         displayrows.add(
           DataRow(
             cells: [
               DataCell(Text(StID[i])),
               DataCell(Text(Fname[i])),
               DataCell(Text(Lname[i])),
               DataCell(Text(ManID[i])),
             ],
           ),
         );
       }
     }
     catch(e) {
       displayrows = [DataRow(
         cells: [
           DataCell(Text('')),
           DataCell(Text('')),
           DataCell(Text('')),
           DataCell(Text('')),
         ],),
       ];
     }
   }
  @override
  State<showscreen> createState() {
    setRows();
   return _showscreenState();
  }
}



class _showscreenState extends State<showscreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(backgroundColor: Colors.black,leading:Icon(Icons.arrow_back),title:Text("College System"),actions: [
    IconButton(icon:Icon(Icons.home),onPressed:(){print("this is pressed"); Navigator.pop(context);})]
      )

    ,body:Column(children: [SizedBox(height: 20),Flexible(

        child:ListView(children: [SingleChildScrollView(
             child: DataTable(columnSpacing: 20,
      columns: [
        DataColumn(
          label: Text('Student ID', style: TextStyle(fontSize: 15),),
        ),
        DataColumn(

          label: Text('First Name', style: TextStyle(fontSize: 15),),
        ),
        DataColumn(
          label: Text('Last Name', style: TextStyle(fontSize: 15),),
        ),
        DataColumn(
          label: Text('Manager ID', style: TextStyle(fontSize: 15),),
        ),
      ],

      rows: displayrows,
    )
    )
        ],
        )
        ,)
    ]
    )
    );

  }
}
Future<String> connect() async {
  String query = "SELECT * FROM student";
  await SqlConn.connect(
      ip: "192.168.1.24",
      port: "1433",
      databaseName: "college2",
      username: "root",
      password: "123456");
  return await SqlConn.readData(query);
}
