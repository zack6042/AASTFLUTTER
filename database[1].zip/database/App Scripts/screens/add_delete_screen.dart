import 'package:flutter/material.dart';


class add_delete extends StatelessWidget {
   add_delete({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}