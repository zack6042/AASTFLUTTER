import 'package:flutter/material.dart';
import 'showscreen.dart';
import 'add_delete_screen.dart';

class Profile extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return(Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(backgroundColor: Colors.black,leading:Icon(Icons.arrow_back),title:Text("College System"),actions: [
          IconButton(icon:Icon(Icons.home),onPressed:(){print("this is pressed"); Navigator.pop(context);}),SizedBox(width:15),InkWell(child: Icon(Icons.settings),onTap:(){Text("No setting available");},),SizedBox(width:15),InkWell(child: Icon(Icons.info_outline),onTap:(){print("NP");},)
        ],),

        body:Column(mainAxisAlignment: MainAxisAlignment.center,children: [Padding(
          padding: const EdgeInsets.only(bottom:10),
          child: Row(mainAxisAlignment:MainAxisAlignment.center,children: [CircleAvatar(radius:60,backgroundImage: AssetImage("images/Arab_Academy_for_Science,_Technology_and_Maritime_Transport_Logo.png"))],),
        ),
          Row(mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            Padding(
              padding: const EdgeInsets.all(20),
              child: ElevatedButton(onPressed:() async{
                String res = await connect();
                Navigator.push(context, MaterialPageRoute(builder: (context){return showscreen(res);}));} ,child:Text("Show"),style:ElevatedButton.styleFrom(primary:Colors.black),)
            ),
          ],
        ),
          Row(mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
              Padding(
              padding: const EdgeInsets.all(20),
          child: ElevatedButton(onPressed:(){Navigator.push(context, MaterialPageRoute(builder: (context){return add_delete();}));} ,child:Text("ADD"),style:ElevatedButton.styleFrom(primary:Colors.black),))],
        ),
        Row(mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              Padding(
                  padding: const EdgeInsets.all(20),
                  child: ElevatedButton(onPressed:(){Navigator.push(context, MaterialPageRoute(builder: (context){return add_delete();}));} ,child:Text("Delete"),style:ElevatedButton.styleFrom(primary:Colors.black),))] )
        ]
        )
      //  ,floatingActionButton:FloatingActionButton(child:Icon(Icons.add)
      //,onPressed:(){print("floating action button is pressed");},
      //tooltip:"no fn yet",
      //),
    )
    );
  }

}