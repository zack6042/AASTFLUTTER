import 'package:flutter/material.dart';
import 'package:untitled5/screens/login_screen.dart';


void main() {
  runApp(MaterialApp(debugShowCheckedModeBanner: false,
    home:Scaffold(appBar: AppBar(title:Text("Login Screen"),backgroundColor: Colors.black,),
        body:LoginScreen()) ,

  )




  );
}


