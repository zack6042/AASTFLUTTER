create database college2 ;
use college2;



create table manager 
(
manid   int not null unique ,
manfname   varchar(20),
manlname     varchar(20),
primary key  (manid)
);


create table student 
(     studid    int not null  ,
	  studfname  varchar(20),
      studlname  varchar(20),
      st_manid int not null,
      primary key (studid),
	  foreign key(st_manid) references manager(manid)
);


create table doctor
(
docid   int not null unique  ,
docfname   varchar(20),
doclname    varchar(20),
street       varchar(20),
city        varchar(20),
country     varchar(20),
d_manid      int not null ,
primary key  (docid),
foreign key(d_manid) references manager(manid)
);


create table class
(
classid  int not null unique  ,
cname      varchar(20) not null unique,
primary key  (classid)
);

create table studclass
(
studid    int not null ,
classid   int not null,
primary key(studid, classid),
foreign key(studid) references student(studid),
foreign key(classid) references class(classid)
);

create table classdoctor
(
classid   int not null ,
docid     int not null,
primary key(classid, docid),
foreign key(classid) references class(classid),
foreign key(docid) references doctor(docid)
);

create table course
(
courseid   int not null unique ,
coursename       varchar(20),
manid     int not null ,
primary key(courseid),
foreign key(manid) references manager(manid)
);

create table class_course
(
courseid int not null,
classid int not null,
primary key(courseid, classid),
foreign key(courseid) references course(courseid),
foreign key(classid) references class(classid)
);

create table doctor_course
(
docid int not null,
courseid int not null,
primary key(docid, courseid),
foreign key(docid) references doctor(docid),
foreign key(courseid) references course(courseid)
);


insert into manager values
(1, 'John', 'Doe'),
(2, 'Jane', 'Doe'),
(3, 'Tom', 'Smith'),
(4, 'Sally', 'Johnson'),
(5, 'David', 'Williams'),
(6, 'Emily', 'Jones'),
(7, 'Michael', 'Brown'),
(8, 'Sarah', 'Miller'),
(9, 'Richard', 'Davis'),
(10, 'Jessica', 'Garcia');

insert into student values
(1, 'Alice', 'Smith', 1),
(2, 'Bob', 'Johnson', 2),
(3, 'Charlie', 'Williams', 3),
(4, 'Donna', 'Jones', 4),
(5, 'Eric', 'Brown', 5),
(6, 'Fiona', 'Miller', 6),
(7, 'Gary', 'Davis', 7),
(8, 'Hannah', 'Garcia', 8),
(9, 'Ivy', 'Taylor', 9),
(10, 'Jack', 'Anderson', 10);

insert into doctor values
(1, 'Adam', 'Smith', 'Main St', 'New York', 'USA', 1),
(2, 'Beth', 'Johnson', 'First Ave', 'Los Angeles', 'USA', 2),
(3, 'Chris', 'Williams', 'Second St', 'Chicago', 'USA', 3),
(4, 'Diane', 'Jones', 'Third Ave', 'Houston', 'USA', 4),
(5, 'Edward', 'Brown', 'Fourth St', 'Philadelphia', 'USA', 5),
(6, 'Fiona', 'Miller', 'Fifth Ave', 'Phoenix', 'USA', 6),
(7, 'Gary', 'Davis', 'Sixth St', 'San Antonio', 'USA', 7),
(8, 'Hannah', 'Garcia', 'Seventh Ave', 'San Diego', 'USA', 8),
(9, 'Ivy', 'Taylor', 'Eighth St', 'Dallas', 'USA', 9),
(10, 'Jack', 'Anderson', 'Ninth Ave', 'San Jose', 'USA', 10);

insert into class values
(1, 'Class A'),
(2, 'Class B'),
(3, 'Class C'),
(4, 'Class D'),
(5, 'Class E'),
(6, 'Class F'),
(7, 'Class G'),
(8, 'Class H'),
(9, 'Class I'),
(10, 'Class J');

insert into studclass values
(1, 1),
(2, 2),
(3, 3),
(4, 4),
(5, 5),
(6, 6),
(7, 7),
(8, 8),
(9, 9),
(10, 10);

insert into classdoctor values
(1, 1),
(2, 2),
(3, 3),
(4, 4),
(5, 5),
(6, 6),
(7, 7),
(8, 8),
(9, 9),
(10, 10);

insert into course values
(1, 'Math', 1),
(2, 'Science', 2),
(3, 'English', 3),
(4, 'History', 4),
(5, 'Art', 5),
(6, 'Music', 6),
(7, 'Physical Education', 7),
(8, 'Technology', 8),
(9, 'Foreign Language', 9),
(10, 'Business', 10);


insert into class_course values
(1, 1),
(2, 2),
(3, 3),
(4, 4),
(5, 5),
(6, 6),
(7, 7),
(8, 8),
(9, 9),
(10, 10);

insert into doctor_course values
(1, 1),
(2, 2),
(3, 3),
(4, 4),
(5, 5),
(6, 6),
(7, 7),
(8, 8),
(9, 9),
(10, 10);

delete from classdoctor where classid = 1 and docid = 1;

update student set studlname = 'Williams' where studid = 2;

select studfname, studlname from student where studid = 3;

--retrieve the names and class names of all students, along with their managers' names:
SELECT s.studfname, s.studlname, c.cname, m.manfname, m.manlname
FROM student s
JOIN class c ON s.studid = c.classid
JOIN manager m ON s.st_manid = m.manid;

SELECT c.coursename, m.manfname, m.manlname
FROM course c
INNER JOIN manager m ON c.manid = m.manid;

